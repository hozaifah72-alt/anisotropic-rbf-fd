include("controlled_solver.jl")
using .Controlled, LinearAlgebra, Random, Printf, SHA, Dates
const O=Controlled.Original
function main()
    BLAS.set_num_threads(1)
    dest=joinpath(@__DIR__,"results");mkpath(dest)
    levels=[0.014,0.010,0.007,0.005,0.0035,0.0028,0.0023]
    coeffs=[0.0,0.05,0.02,0.10]
    seeds=[1234,2345,3456]
    configs=[("P4",[(i,j) for j in 0:4 for i in 0:(4-j)]),
             ("Q41",O.monomial_exponents(4,1)),("Q42",O.monomial_exponents(4,2))]
    @assert length(configs[1][2])==15
    @assert Set(configs[1][2])!=Set(configs[3][2])
    open(joinpath(dest,"settings.txt"),"w") do io
        println(io,"Julia=",VERSION,"; CPU=",Sys.CPU_NAME,"; threads=",Threads.nthreads(),"; BLAS_threads=1")
        println(io,"seeds=",seeds,"; reset once per seven-level sequence; jitter=0.1; kappa=50; Strategy B; n=30")
        println(io,"levels=",levels,"; coefficients=",coeffs)
        println(io,"Shared nodes for all bases and coefficients at each seed/level. Four RHS share one factorisation. Timings are single-run diagnostic records, not replicated benchmarks.")
        for file in ["run_study.jl","controlled_solver.jl","original_local_solver.jl"]
            println(io,file," SHA256=",bytes2hex(sha256(read(joinpath(@__DIR__,file)))))
        end
    end
    Random.seed!(O.RNG,1234);nodes,bnd=O.generate_nodes(0.03;anisotropic=true)
    for (_,exps) in configs;Controlled.solve_cases(nodes,bnd,.03,exps,30,coeffs);end
    open(joinpath(dest,"results.csv"),"w") do io
        println(io,"seed,smin,N,basis,q,n,a,rms,max_error,tau_rms,relative_residual,assembly_seconds,factor_seconds,solve_seconds")
        for seed in seeds
            Random.seed!(O.RNG,seed)
            for s in levels
                nodes,bnd=O.generate_nodes(s;anisotropic=true,jitter=0.1)
                open(joinpath(dest,"nodes_seed$(seed)_$(s).csv"),"w") do nf
                    println(nf,"x,y,boundary")
                    for j in axes(nodes,1);println(nf,nodes[j,1],",",nodes[j,2],",",Int(bnd[j]));end
                end
                for (basis,exps) in configs
                    res=Controlled.solve_cases(nodes,bnd,s,exps,30,coeffs)
                    for (a,r) in zip(coeffs,res)
                        println(io,join((seed,s,size(nodes,1),basis,length(exps),30,a,r.rms,r.maxerr,r.tau,r.residual,r.assembly,r.factor,r.solve),","))
                    end
                    flush(io)
                    @printf("seed=%d s=%.4f N=%d %s RMS(a=.05)=%.6e assembly=%.2fs\n",seed,s,size(nodes,1),basis,res[2].rms,res[2].assembly);flush(stdout)
                end
            end
        end
    end
    println("COMPLETE ",dest)
end
if abspath(PROGRAM_FILE)==@__FILE__;main();end
