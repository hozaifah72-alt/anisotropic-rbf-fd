module Original
using LinearAlgebra
using SparseArrays
using Statistics
using Printf
using Random



const RNG = MersenneTwister(1234)

# ---------------------------------------------------------------------------
# Spacing function with s_max = 3 s_min
# ---------------------------------------------------------------------------
s25(x, smin) = smin + 2smin * (1 - exp(-3x)) / (1 - exp(-3))

# ---------------------------------------------------------------------------
# Node generation (column-based)
#   anisotropic = false : local spacing s(x) in BOTH directions
#   anisotropic = true  : s_x = s(x), s_y = s_max (constant)
# Interior nodes are jittered to break distance ties on tensor-like grids.
# ---------------------------------------------------------------------------
function generate_nodes(smin; anisotropic::Bool, jitter::Float64 = 0.1)
    smax = 3smin

    # x-columns; overshoot then rescale so last column is x = 1
    xs = [0.0]
    while xs[end] < 1.0
        push!(xs, xs[end] + s25(xs[end], smin))
    end
    xs ./= xs[end]

    pts = Float64[]
    bnd = Bool[]
    for x in xs
        sy = anisotropic ? smax : s25(x, smin)
        ny = max(3, round(Int, 1 / sy) + 1)
        for y in range(0.0, 1.0, length = ny)
            onb = (x == 0.0) || (x == 1.0) || (y == 0.0) || (y == 1.0)
            xx, yy = x, y
            if !onb
                sx = s25(x, smin)
                xx += jitter * sx * (2rand(RNG) - 1)
                yy += jitter * sy * (2rand(RNG) - 1)
            end
            push!(pts, xx); push!(pts, yy)
            push!(bnd, onb)
        end
    end
    nodes = permutedims(reshape(pts, 2, :))   # N × 2
    return nodes, bnd
end

# ---------------------------------------------------------------------------
# Tensor-product monomial exponents
#   0 ≤ a ≤ Px and 0 ≤ b ≤ Py, so q = (Px+1)(Py+1).
# The degrees are supplied separately for every comparison case.
# ---------------------------------------------------------------------------
function monomial_exponents(Px::Int, Py::Int)
    e = Tuple{Int,Int}[]
    for b in 0:Py, a in 0:Px
        push!(e, (a, b))
    end
    return e
end

# ---------------------------------------------------------------------------
# RBF-FD Laplacian weights at one interior node.
# MQ with directional shape factors (ε_x, ε_y). Local coordinates are
# centered at the node and scaled by the stencil radius h; the physical
# Laplacian is recovered by dividing the weights by h².
#
# With u = ε_x Δx, v = ε_y Δy and φ = √(1 + u² + v²):
#   ∇²φ = [ε_x²(1 + v²) + ε_y²(1 + u²)] / φ³
# ---------------------------------------------------------------------------
function laplacian_weights(nodes::Matrix{Float64}, idx::Vector{Int}, ic::Int,
                           ex_phys::Float64, ey_phys::Float64,
                           exps::Vector{Tuple{Int,Int}})
    n = length(idx)
    q = length(exps)

    ξx = nodes[idx, 1] .- nodes[ic, 1]
    ξy = nodes[idx, 2] .- nodes[ic, 2]
    h  = maximum(hypot.(ξx, ξy))
    ξx ./= h; ξy ./= h
    ex, ey = ex_phys * h, ey_phys * h

    M = zeros(n + q, n + q)
    @inbounds for j in 1:n, i in 1:n
        u = ex * (ξx[i] - ξx[j])
        v = ey * (ξy[i] - ξy[j])
        M[i, j] = sqrt(1 + u^2 + v^2)
    end
    for (j, (a, b)) in enumerate(exps)
        for i in 1:n
            M[i, n + j] = ξx[i]^a * ξy[i]^b
            M[n + j, i] = M[i, n + j]
        end
    end

    rhs = zeros(n + q)
    @inbounds for i in 1:n
        u = ex * ξx[i]
        v = ey * ξy[i]
        s = 1 + u^2 + v^2
        rhs[i] = (ex^2 * (1 + v^2) + ey^2 * (1 + u^2)) / s^1.5
    end
    for (j, (a, b)) in enumerate(exps)
        if (a, b) == (2, 0) || (a, b) == (0, 2)
            rhs[n + j] = 2.0
        end
    end

    w = try
        M \ rhs
    catch
        qr(M, ColumnNorm()) \ rhs
    end
    return w[1:n] ./ h^2
end

# ---------------------------------------------------------------------------

end
