include("controlled_solver.jl")
using .Controlled, LinearAlgebra, DelimitedFiles, Printf
BLAS.set_num_threads(1)
O=Controlled.Original
exps=[(i,j) for j in 0:4 for i in 0:(4-j)]
open(joinpath(@__DIR__,"results","P4_exactness.csv"),"w") do io
    println(io,"seed,smin,sampled_stencils,worst_dimensionless_moment_residual")
    for seed in [1234,2345,3456], smin in [0.014,0.0023]
        data=readdlm(joinpath(@__DIR__,"results","nodes_seed$(seed)_$(smin).csv"),',',Float64;skipstart=1)
        nodes=Matrix(data[:,1:2]);ids=findall(data[:,3].==0)
        sample=ids[unique(round.(Int,range(1,length(ids);length=25)))];worst=0.0
        for ic in sample
            sx=O.s25(nodes[ic,1],smin);sy=3smin
            dist=((nodes[:,1].-nodes[ic,1])./sx).^2+((nodes[:,2].-nodes[ic,2])./sy).^2
            idx=collect(partialsortperm(dist,1:30))
            w=O.laplacian_weights(nodes,idx,ic,.5/sy,.5/sy,exps)
            dx=nodes[idx,1].-nodes[ic,1];dy=nodes[idx,2].-nodes[ic,2];h=maximum(hypot.(dx,dy))
            for (a,b) in exps
                target=(a,b) in [(2,0),(0,2)] ? 2.0 : 0.0
                defect=abs(h^2*sum(w.*(dx./h).^a.*(dy./h).^b)-target)
                worst=max(worst,defect)
            end
        end
        @assert worst<1e-9 "P4 sampled exactness failure"
        println(io,join((seed,smin,length(sample),worst),","));flush(io)
        @printf("P4 seed=%d smin=%.4f sampled=%d worst=%.3e\n",seed,smin,length(sample),worst)
    end
end
