module Controlled
using LinearAlgebra, SparseArrays, Statistics, Random, Printf, SHA, Dates
include("original_local_solver.jl")
function solve_cases(nodes,bnd,smin,exps,n,coeffs)
    N=size(nodes,1); ids=findall(.!bnd); ni=length(ids)
    g2i=zeros(Int,N); g2i[ids]=1:ni
    U=hcat([exp.(-50 .* nodes[:,1]) .* (1 .+ a .* nodes[:,2].^2) for a in coeffs]...)
    F=hcat([exp.(-50 .* nodes[ids,1]) .* (2500 .* (1 .+ a .* nodes[ids,2].^2) .+ 2a) for a in coeffs]...)
    rhs=copy(F); trunc=-copy(F)
    ii=Int[];jj=Int[];vv=Float64[];d2=zeros(N)
    t=time_ns()
    for (k,ic) in enumerate(ids)
        sx=Original.s25(nodes[ic,1],smin); sy=3smin
        @inbounds for j in 1:N
            d2[j]=((nodes[j,1]-nodes[ic,1])/sx)^2+((nodes[j,2]-nodes[ic,2])/sy)^2
        end
        idx=collect(partialsortperm(d2,1:n))
        w=Original.laplacian_weights(nodes,idx,ic,0.5/sy,0.5/sy,exps)
        for (l,j) in enumerate(idx)
            for c in eachindex(coeffs)
                trunc[k,c]+=w[l]*U[j,c]
            end
            if bnd[j]
                for c in eachindex(coeffs);rhs[k,c]-=w[l]*U[j,c];end
            else
                push!(ii,k);push!(jj,g2i[j]);push!(vv,w[l])
            end
        end
    end
    A=sparse(ii,jj,vv,ni,ni); assembly=(time_ns()-t)/1e9
    t=time_ns(); factor=lu(A); factor_seconds=(time_ns()-t)/1e9
    out=[]
    for c in eachindex(coeffs)
        t=time_ns(); v=factor\rhs[:,c]; solve_seconds=(time_ns()-t)/1e9
        uh=copy(U[:,c]);uh[ids]=v
        err=uh-U[:,c]; normu=maximum(abs.(U[:,c]))
        residual=norm(A*v-rhs[:,c],Inf)/max(norm(rhs[:,c],Inf),eps())
        push!(out,(rms=sqrt(mean(abs2,err))/normu,maxerr=maximum(abs.(err))/normu,
                   tau=sqrt(mean(abs2,trunc[:,c]))/maximum(abs.(F[:,c])),residual=residual,
                   assembly=assembly,factor=factor_seconds,solve=solve_seconds))
    end
    out
end

end
