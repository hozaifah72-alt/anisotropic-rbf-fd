Anisotropic RBF-FD controlled polynomial-space comparison

Supplementary code and data for the revised conference manuscript.
This archive has not been assigned a public DOI or repository URL.

REQUIREMENTS AND RUNNING
Julia 1.12.6 was used; the numerical drivers use standard libraries only.
Extract to a NEW folder before rerunning so the archived results are preserved.
From that folder run:
    julia --startup-file=no run_study.jl
    julia --startup-file=no verify_polynomials.jl
Optional original single-seed controls:
    julia --startup-file=no run_historical_controls.jl
Optional figure regeneration (Python with matplotlib and numpy):
    python -m pip install -r plot_requirements.txt
    python plot_results.py

EXPERIMENT
Square [0,1]^2; Poisson equation; exact Dirichlet data;
u=exp(-50*x)*(1+a*y^2), a=0,0.02,0.05,0.10.
Strategy B, transformed nearest neighbours, jitter=0.1.
P4, Q41 and Q42 all use n=30.
Seeds:1234,2345,3456. Each seed is reset once, then the seven levels are
generated in the listed order. Nodes and neighbours are shared across bases
within each seed/level. The seed is not reset separately at every level.
All RHS share each assembled operator and factorization.

CONTENTS
results/results.csv:252 solution records (3 seeds x7 levels x3 bases x4 RHS).
results/nodes_*.csv:exact coordinates and boundary flags for all21 node sets.
results/paired_ratios.csv:within-seed paired RMS ratios.
results/P4_exactness.csv:sampled polynomial reproduction checks.
results/settings.txt:runtime settings and hashes of the executed source.
historical_single_seed/:earlier Q41 n20/n30,Q42 n30,Q43 n40 controls.
summary.json:paired comparison summaries and reproduction check.
SHA256SUMS.txt:checksums of packaged files.

NORMALIZATION AND LIMITS
RMS averages over all nodes, including exact boundary nodes, then divides by
max(abs(u_exact)). Truncation RMS is interior-only, divided by max(abs(f)).
Recorded timings are single measurements, not replicated timing benchmarks.
Three seeds are a sensitivity check, not a general statistical guarantee.
Q41 omits y^2; these data do not establish full quadratic exactness for it.
The historical data and new data are explicitly separate.

PUBLIC RELEASE
Upload this archive to the authors' chosen repository and use its actual URL
or DOI in the manuscript. Authors must choose any public licence and confirm
metadata. No licence, DOI, URL or publication status has been invented.
