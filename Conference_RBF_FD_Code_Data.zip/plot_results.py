from pathlib import Path
import csv,json,sys,math
R=Path(__file__).parent;ROOT=R.parent
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
def read(p):
 with open(p,newline='',encoding='utf-8-sig') as f:return [{k:(v if k=='basis' else float(v)) for k,v in x.items()} for x in csv.DictReader(f)]
r=read(R/'results/results.csv');old=read(R/'historical_single_seed/results.csv')
assert len(r)==252,len(r)
def series(seed,basis,a):return sorted([x for x in r if x['seed']==seed and x['basis']==basis and x['a']==a],key=lambda x:x['N'])
maxdiff=0
for x in r:
 if x['seed']==1234 and x['basis'] in ['Q41','Q42']:
  y=next(y for y in old if y['smin']==x['smin'] and y['a']==x['a'] and y['n']==30 and y['py']==(1 if x['basis']=='Q41' else 2))
  maxdiff=max(maxdiff,abs(x['rms']-y['rms'])/y['rms'])
  assert math.isclose(x['rms'],y['rms'],rel_tol=1e-8,abs_tol=1e-12)
for s in sorted(set(x['smin'] for x in r)):
 a=list(csv.reader(open(R/f'historical_single_seed/nodes_{s}.csv')))
 b=list(csv.reader(open(R/f'results/nodes_seed1234_{s}.csv')))
 assert a==b,f'Node mismatch at {s}'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10,'savefig.dpi':220})
fig,axs=plt.subplots(2,2,figsize=(9,6.9))
for ax,a in zip(axs.flat,[0,.05,.02,.1]):
 for basis,color,marker in [('P4','#222222','d'),('Q41','#c77500','o'),('Q42','#198640','s')]:
  q=series(1234,basis,a);ax.loglog([x['N'] for x in q],[x['rms'] for x in q],marker=marker,color=color,ms=3,label={'P4':'P=4, n=30','Q41':'Q(4,1), n=30','Q42':'Q(4,2), n=30'}[basis])
 for py,n,col,m in [(1,20,'#2379c2','v'),(3,40,'#b44565','^')]:
  q=sorted([x for x in old if x['a']==a and x['py']==py and x['n']==n],key=lambda x:x['N']);ax.loglog([x['N'] for x in q],[x['rms'] for x in q],'--',marker=m,ms=3,lw=.9,color=col,label=f'Q(4,{py}), n={n}')
 ax.set(title=f'a = {a:g}',xlabel='Number of nodes N',ylabel='Normalized RMS error');ax.grid(True,which='both',alpha=.15);ax.legend(fontsize=6.5)
fig.tight_layout();fig.savefig(R/'controlled_with_P4.png');plt.close(fig)
stats={'max_reproduction_relative_difference':maxdiff,'max_residual':max(x['relative_residual'] for x in r),'coefficients':{}}
fig,axs=plt.subplots(2,2,figsize=(9,6.4))
records=[]
for ax,a in zip(axs.flat,[0,.05,.02,.1]):
 allrat=[];allp=[];fin=[]
 for seed,marker in zip([1234,2345,3456],['o','s','^']):
  q1=series(seed,'Q41',a);q2=series(seed,'Q42',a);p=series(seed,'P4',a)
  ratios=[x['rms']/y['rms'] for x,y in zip(q1,q2)]
  allrat+=ratios;allp += [x['rms']/y['rms'] for x,y in zip(q2,p)];fin.append(ratios[-1])
  ax.semilogx([x['N'] for x in q1],ratios,marker=marker,ms=4,label=f'Seed {seed}')
  for x,y,z,ratio in zip(q1,q2,p,ratios):records.append([seed,a,x['smin'],int(x['N']),x['rms'],y['rms'],z['rms'],ratio,y['rms']/z['rms']])
 ax.axhline(1,color='black',ls='--',lw=.9);ax.set(title=f'a = {a:g}',xlabel='Number of nodes N',ylabel='RMS Q(4,1) / RMS Q(4,2)');ax.grid(True,alpha=.2);ax.legend(fontsize=7)
 stats['coefficients'][str(a)]={'ratio_min':min(allrat),'ratio_max':max(allrat),'wins':sum(x<1 for x in allrat),'count':len(allrat),'finest_ratios':fin,'q42_p4_min':min(allp),'q42_p4_max':max(allp)}
fig.tight_layout();fig.savefig(R/'three_seed_ratios.png');plt.close(fig)
with open(R/'results/paired_ratios.csv','w',newline='') as f:
 w=csv.writer(f);w.writerow(['seed','a','smin','N','Q41_rms','Q42_rms','P4_rms','Q41_Q42_ratio','Q42_P4_ratio']);w.writerows(records)
(R/'summary.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
