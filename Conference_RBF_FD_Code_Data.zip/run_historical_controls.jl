module ConferenceControlledTests
using LinearAlgebra, SparseArrays, Statistics, Random, Printf, SHA, Dates
const SOURCE = joinpath(@__DIR__,"original_local_solver.jl")
include("original_local_solver.jl")

function solve_cases(nodes,bnd,smin,px,py,n,coeffs)
    N=size(nodes,1); ids=findall(.!bnd); ni=length(ids)
    g2i=zeros(Int,N); g2i[ids]=1:ni
    U=hcat([exp.(-50 .* nodes[:,1]) .* (1 .+ a .* nodes[:,2].^2) for a in coeffs]...)
    F=hcat([exp.(-50 .* nodes[ids,1]) .* (2500 .* (1 .+ a .* nodes[ids,2].^2) .+ 2a) for a in coeffs]...)
    rhs=copy(F); trunc=-copy(F)
    ii=Int[];jj=Int[];vv=Float64[];d2=zeros(N)
    exps=Original.monomial_exponents(px,py)
    t=time_ns()
    for (k,ic) in enumerate(ids)
        sx=Original.s25(nodes[ic,1],smin); sy=3smin
        @inbounds for j in 1:N
            d2[j]=((nodes[j,1]-nodes[ic,1])/sx)^2+((nodes[j,2]-nodes[ic,2])/sy)^2
        end
        idx=collect(partialsortperm(d2,1:n))
        w=Original.laplacian_weights(nodes,idx,ic,0.5/sy,0.5/sy,exps)
        for (l,j) in enumerate(idx)
            for c in eachindex(coeffs)
                trunc[k,c]+=w[l]*U[j,c]
            end
            if bnd[j]
                for c in eachindex(coeffs);rhs[k,c]-=w[l]*U[j,c];end
            else
                push!(ii,k);push!(jj,g2i[j]);push!(vv,w[l])
            end
        end
    end
    A=sparse(ii,jj,vv,ni,ni); assembly=(time_ns()-t)/1e9
    t=time_ns(); factor=lu(A); factor_seconds=(time_ns()-t)/1e9
    out=[]
    for c in eachindex(coeffs)
        t=time_ns(); v=factor\rhs[:,c]; solve_seconds=(time_ns()-t)/1e9
        uh=copy(U[:,c]);uh[ids]=v
        err=uh-U[:,c]; normu=maximum(abs.(U[:,c]))
        residual=norm(A*v-rhs[:,c],Inf)/max(norm(rhs[:,c],Inf),eps())
        push!(out,(rms=sqrt(mean(abs2,err))/normu,maxerr=maximum(abs.(err))/normu,
                   tau=sqrt(mean(abs2,trunc[:,c]))/maximum(abs.(F[:,c])),residual=residual,
                   assembly=assembly,factor=factor_seconds,solve=solve_seconds))
    end
    out
end

function run(;output=joinpath(@__DIR__,"historical_rerun"))
    mkpath(output); BLAS.set_num_threads(1)
    levels=[0.014,0.010,0.007,0.005,0.0035,0.0028,0.0023]
    coeffs=[0.0,0.05,0.02,0.10]
    # Both Q(4,1) and Q(4,2) use identical 30-neighbour sets.
    # Q(4,1), n=20 and Q(4,3), n=40 retain the old n=2q rule.
    configs=[(4,1,20),(4,1,30),(4,2,30),(4,3,40)]
    open(joinpath(output,"settings.txt"),"w") do io
        println(io,"New controlled experiments; not replacement of historical runs.")
        println(io,"source=",SOURCE,"\nsource_sha256=",bytes2hex(sha256(read(SOURCE))))
        println(io,"Julia=",VERSION,"\nseed=1234; jitter=0.1; BLAS threads=1; Julia threads=",Threads.nthreads())
        println(io,"levels=",levels,"\ncoefficients=",coeffs,"\nconfigs=",configs)
        println(io,"Warm-up excluded. Assembly includes neighbour search and weights. One factorization shared by four RHS. Single timings, not replicated benchmark.")
    end
    Random.seed!(Original.RNG,1234)
    nodes,bnd=Original.generate_nodes(0.03;anisotropic=true)
    for (px,py,n) in configs; solve_cases(nodes,bnd,0.03,px,py,n,coeffs);end
    Random.seed!(Original.RNG,1234)
    open(joinpath(output,"results.csv"),"w") do io
        println(io,"smin,N,px,py,n,a,rms,max_error,tau_rms,relative_residual,assembly_seconds,factor_seconds,solve_seconds")
        for s in levels
            nodes,bnd=Original.generate_nodes(s;anisotropic=true)
            open(joinpath(output,"nodes_$(s).csv"),"w") do nf
                println(nf,"x,y,boundary")
                for j in axes(nodes,1);println(nf,nodes[j,1],",",nodes[j,2],",",Int(bnd[j]));end
            end
            for (px,py,n) in configs
                res=solve_cases(nodes,bnd,s,px,py,n,coeffs)
                for (a,r) in zip(coeffs,res)
                    println(io,join((s,size(nodes,1),px,py,n,a,r.rms,r.maxerr,r.tau,r.residual,r.assembly,r.factor,r.solve),","))
                end
                flush(io)
                @printf("s=%.4f N=%d Q(%d,%d) n=%d RMS(a=.05)=%.5e assembly=%.2fs factor=%.2fs\n",s,size(nodes,1),px,py,n,res[2].rms,res[2].assembly,res[2].factor)
                flush(stdout)
            end
        end
    end
    println("Completed: ",output)
end
end
if abspath(PROGRAM_FILE)==@__FILE__;ConferenceControlledTests.run();end
